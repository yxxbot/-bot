import sys
import sqlite3
import datetime


class UserList:
    def __init__(self):
        self.count = 0
        self.end_time = datetime.datetime(2000, 1, 1, 0, 0, 0, 0)

    def activate(self, user_id, count=0):
        user_id = str(user_id)
        self.count += count
        if not (self.count % 5) and self.count:
            if not self.end_time:
                self.end_time = datetime.datetime.now() + datetime.timedelta(hours=24)
            elif self.end_time <= datetime.datetime.now():
                self.end_time = datetime.datetime.now() + datetime.timedelta(hours=24)
            else:
                self.end_time += datetime.timedelta(hours=24)
        conn = sqlite3.connect(f"{sys.path[0]}/data.db")
        conn.execute(
            f"""UPDATE user SET count = {self.count}, end_time = '{datetime.datetime.strftime(self.end_time, "%Y-%m-%d %H:%M:%S")}' WHERE tg_id = {user_id}"""
        )
        conn.commit()
        conn.close()

    def active(self):
        if self.end_time == 0:
            return False
        elif self.end_time > datetime.datetime.now():
            return True
        return False


def _init():  # 初始化
    global userlist, admin_list, super_admin, ban_list, conn
    userlist = {}
    admin_list = []
    ban_list = []
    with open(f"{sys.path[0]}/conf", "r", encoding="utf-8") as f:
        lines = f.readlines()
        for line in lines:
            if line[0] != "#" and line[0] != "t":
                admin_list.append(line.strip())
    super_admin = admin_list.copy()
    conn = sqlite3.connect(f"{sys.path[0]}/data.db")
    cursor = conn.execute("PRAGMA table_info(admin)")
    if len(cursor.fetchall()) == 0:
        conn.execute("CREATE TABLE IF NOT EXISTS admin (tg_id TEXT PRIMARY KEY)")
        conn.commit()
    else:
        cursor = conn.execute("SELECT * FROM admin")
        for row in cursor:
            admin_list.append(row[0])
    cursor = conn.execute("PRAGMA table_info(ban)")
    if len(cursor.fetchall()) == 0:
        conn.execute("CREATE TABLE IF NOT EXISTS ban (tg_id TEXT PRIMARY KEY)")
        conn.commit()
    else:
        cursor = conn.execute("SELECT * FROM ban")
        for row in cursor:
            ban_list.append(row[0])
    cursor = conn.execute("PRAGMA table_info(user)")
    if len(cursor.fetchall()) == 0:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS user (tg_id TEXT PRIMARY KEY, count INTEGER, end_time TEXT)"
        )
        conn.commit()
    else:
        cursor = conn.execute("SELECT * FROM user")
        for row in cursor:
            userlist[row[0]] = UserList()
            userlist[row[0]].count = row[1]
            userlist[row[0]].end_time = datetime.datetime.strptime(
                row[2], "%Y-%m-%d %H:%M:%S"
            )
    conn.close()
    return admin_list


def set_value(user_id):
    user_id = str(user_id)
    userlist[user_id] = UserList()
    conn = sqlite3.connect(f"{sys.path[0]}/data.db")
    conn.execute(
        f"""INSERT INTO user (tg_id, count, end_time) VALUES ({user_id}, 0, "2000-01-01 00:00:00")"""
    )
    conn.commit()
    conn.close()


def get_value(user_id):
    user_id = str(user_id)
    return userlist[user_id]


def get_active_user():
    active_user = []
    for user in userlist:
        if userlist[user].active():
            active_user.append(user)
    return active_user


def get_admin_list():
    return admin_list


def add_admin(user_id):
    user_id = str(user_id)
    admin_list.append(user_id)
    conn = sqlite3.connect(f"{sys.path[0]}/data.db")
    conn.execute(f"INSERT INTO admin (tg_id) VALUES ({user_id})")
    conn.commit()
    conn.close()


def del_admin(user_id):
    user_id = str(user_id)
    admin_list.remove(user_id)
    conn = sqlite3.connect(f"{sys.path[0]}/data.db")
    conn.execute(f"DELETE FROM admin WHERE tg_id = {user_id}")
    conn.commit()
    conn.close()


def get_super_admin():
    return super_admin


def add_ban(user_id):
    user_id = str(user_id)
    ban_list.append(user_id)
    conn = sqlite3.connect(f"{sys.path[0]}/data.db")
    conn.execute(f"INSERT INTO ban (tg_id) VALUES ({user_id})")
    conn.commit()
    conn.close()


def del_ban(user_id):
    user_id = str(user_id)
    ban_list.remove(user_id)
    conn = sqlite3.connect(f"{sys.path[0]}/data.db")
    conn.execute(f"DELETE FROM ban WHERE tg_id = {user_id}")
    conn.commit()
    conn.close()


def get_ban_list():
    return ban_list
