import os
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackContext,
    MessageHandler,
    filters,
)

from tools import *


async def start(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    admin_list = userconf.get_admin_list()
    super_admin = userconf.get_super_admin()
    if str(user) in super_admin:
        await update.message.reply_text(
            "每发送五个视频激活24H\n使用 /activate 查询激活状态\n使用 /add_admin + user_id 添加管理员\n使用 /del_admin + user_id 删除管理员\n使用 /list_admin 查看当前管理员\n使用 /ban + user_id 封禁用户\n使用 /unban + user_id 解封用户\n使用 /list_ban 查看已封禁用户"
        )
    elif str(user) in admin_list:
        await update.message.reply_text(
            "每发送五个视频激活24H\n使用 /activate 查询激活状态\n使用 /ban + user_id 封禁用户\n使用 /unban + user_id 解封用户\n使用 /list_ban 查看已封禁用户"
        )
    else:
        await update.message.reply_text("每发送五个视频激活24H\n使用 /activate 查询激活状态")


async def added_admin(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    add_user = update.message.text.split(" ")[1]
    admin_list = userconf.get_admin_list()
    super_admin = userconf.get_super_admin()
    if str(user) in super_admin:
        if add_user in admin_list:
            await update.message.reply_text("已经是管理员")
        else:
            userconf.add_admin(add_user)
            await update.message.reply_text("添加成功")


async def delete_admin(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    del_user = update.message.text.split(" ")[1]
    admin_list = userconf.get_admin_list()
    super_admin = userconf.get_super_admin()
    if str(user) in super_admin:
        if del_user in admin_list:
            if del_user in super_admin:
                await update.message.reply_text("超级管理员，无法删除")
            else:
                userconf.del_admin(del_user)
                await update.message.reply_text("删除成功")
        else:
            await update.message.reply_text("非管理员用户，无需删除")


async def list_admin(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    admin_list = userconf.get_admin_list()
    super_admin = userconf.get_super_admin()
    if str(user) in super_admin:
        text = "".join([f"{i}\n" for i in admin_list])
        await update.message.reply_text(text)


def main():
    application = ApplicationBuilder().token(f"{token}").build()

    """  START/HELP  """
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", start))

    """ start  """
    application.add_handler(MessageHandler(filters.VIDEO, video_forward))
    application.add_handler(CommandHandler("activate", activate))
    application.add_handler(CommandHandler("ban", ban))
    application.add_handler(CommandHandler("unban", unban))
    application.add_handler(CommandHandler("list_ban", list_ban))
    application.add_handler(CommandHandler("add_admin", added_admin))
    application.add_handler(CommandHandler("del_admin", delete_admin))
    application.add_handler(CommandHandler("list_admin", list_admin))
    """  end  """

    application.run_polling()  # 不终止tg-bot


if __name__ == "__main__":
    with open("conf", "r", encoding="utf-8") as f:
        token = f.readline().split('"')[1]
    userconf._init()
    main()
