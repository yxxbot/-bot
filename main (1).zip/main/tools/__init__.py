from .userconf import (
    set_value,
    get_value,
    get_active_user,
    get_admin_list,
    get_super_admin,
    get_ban_list,
    add_ban,
    del_ban,
)

from telegram import Update, Bot
from telegram.ext import CallbackContext


async def video_forward(update: Update, context: Bot):
    user = update.effective_user.id
    admin_list = get_admin_list()
    super_admin = get_super_admin()
    ban_list = get_ban_list()
    try:
        user_list = get_value(user)
    except KeyError:
        set_value(user)
        user_list = get_value(user)
    if str(user) in ban_list:
        await update.message.reply_text("已经被封禁")
    else:
        user_list.activate(user, count=1)
        if user_list.active():  # 检测是否激活
            await update.message.reply_text(f"到期时间: {user_list.end_time}")
        else:
            await update.message.reply_text(f"再发送{5 - user_list.count}个视频激活")
        # 发送给激活用户视频
        video = update.message.video
        user_list = get_active_user()
        try:
            user_list.remove(str(user))  # 去除自己
        except ValueError:
            pass
        for s_u in super_admin:
            try:
                user_list.remove(s_u)  # 去除超级管理员
            except ValueError:
                pass
        for b_u in ban_list:
            try:
                user_list.remove(b_u)
            except ValueError:
                pass
        for u in user_list:
            await context.bot.send_video(u, video=video)
        # 发送给超级管理员
        for super_user in super_admin:
            await context.bot.send_video(super_user, video=video)
            await context.bot.send_message(super_user, f"视频发送者：{user}")


async def activate(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    ban_list = get_ban_list()
    if str(user) in ban_list:
        await update.message.reply_text("已经被封禁")
    else:
        try:
            user_list = get_value(user)
        except KeyError:
            set_value(user)
            user_list = get_value(user)
        if user_list.active():
            await update.message.reply_text(f"到期时间: {user_list.end_time}")
        else:
            await update.message.reply_text(f"再发送{5 - user_list.count}个视频激活")


async def ban(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    admin_list = get_admin_list()
    ban_list = get_ban_list()
    if str(user) in admin_list:
        ban_user = update.message.text.split(" ")[1]
        if ban_user in ban_list:
            await update.message.reply_text("已经封禁")
        elif ban_user in admin_list:
            await update.message.reply_text("管理员，无法封禁")
        else:
            add_ban(ban_user)
            await update.message.reply_text("已封禁")


async def unban(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    unban_user = update.message.text.split(" ")[1]
    admin_list = get_admin_list()
    ban_list = get_ban_list()
    if str(user) in admin_list:
        if unban_user in ban_list:
            del_ban(unban_user)
            await update.message.reply_text("解封成功")
        else:
            await update.message.reply_text("未被封禁")


async def list_ban(update: Update, context: CallbackContext.DEFAULT_TYPE):
    user = update.effective_user.id
    admin_list = get_admin_list()
    if str(user) in admin_list:
        ban_list = get_ban_list()
        text = "".join([f"{i}\n" for i in ban_list])
        if text:
            await update.message.reply_text(text)
        else:
            await update.message.reply_text("无封禁用户")
